#!/bin/bash
echo "This is the deploy.sh script"
